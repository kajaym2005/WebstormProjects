'use strict';

angular.module('angularApp')
  .controller('MainCtrl', function ($scope) {
   
  });





angular.module('angularApp')
	.controller('planeController', ['$scope','$resource','$routeParams','$timeout','FlightService',
				function ($scope,$resource, $routeParams,$timeout,FlightService) {
	
		//Mapping data from URL paramenter
		$scope.flightName= $routeParams.flightName;
		
		
	  
 		//Retrieving data from services
		FlightService.detail($scope.flightName,function(data){		    
		  		$scope.flight=data;
		  });
		FlightService.getShipments($scope.flightName,function(data){		    
		  		$scope.shipments=data;
		  });


		//FILTER
		$scope.$watch('shipments', function(newVal,oldVal) 
		{
			if (newVal===undefined) return;
			//Create criteria object for filtering
			$scope.filterCriteria={
				flags:{
					priority:false,
					cold:false,
					big:false,
					dangerous:false,
					fashion:false,
					live:false,
				},
				weight:{
					max:10000,
					min:0,
					valueMax:10000,
					valueMin:0
				},
				vol:{
					max:1000,
					min:0,
					valueMax:1000,
					valueMin:0
				}
			}
			var wMax=0,wMin=1000,vMax=0,vMin=1000;
			//Calculating Max and Min values for double-slider components
			angular.forEach($scope.shipments, function(value, key){ 
					if (wMax<value.weight) wMax=value.weight;
					if (wMin>value.weight) wMin=value.weight;
					if (vMax<value.vol) vMax=value.vol;
					if (vMin>value.vol) vMin=value.vol;
			});
			$scope.filterCriteria.weight.valueMax=$scope.filterCriteria.weight.max=wMax;
			$scope.filterCriteria.weight.valueMin=$scope.filterCriteria.weight.min=wMin;
			$scope.filterCriteria.vol.valueMax=$scope.filterCriteria.vol.max=vMax;
			$scope.filterCriteria.vol.valueMin=$scope.filterCriteria.vol.min=vMin;
			$scope.$broadcast('refreshSlider'); //Send event for refreshing component
			$scope.resetFilterCriteria=angular.copy($scope.filterCriteria); //Back up original filter for restoring it in the cancel option
		});

		//Operations
		$scope.openFilter=function(){
			$('#filterShipment').show('slow',function(){
			$scope.$broadcast('refreshSlider');
			});
		}
		$scope.applyFilter=function(){
			$('#filterShipment').hide('slow');


		}
		$scope.cancelFilter=function(){
			$scope.filterCriteria=angular.copy($scope.resetFilterCriteria);
			$('#filterShipment').hide('slow');
		}


		//DRAG&DROP
		$scope.startDrag=function(e,helper,shipment){

			
		}
	 	$scope.addShipment=function(e,ui){
	 		var element=$(e.target);
	 		
	 		var droppedShipment =ui.draggable.scope().ship;
	 		var targetULD=element.scope().uld;
			if (FlightService.addShipmentsToULD ($scope.flight,targetULD,[droppedShipment]))
			{
				element.removeClass("animated").removeClass("rubberBand");
				$timeout(function() {
		 			element.addClass("animated").addClass("rubberBand")
		 		});
		 		var index=$scope.shipments.indexOf(droppedShipment);
	 			$scope.shipments.splice(index,1);   
 			}

 			
	 	}
	}]);


//CUSTOM FILTER FOR SHIPMENTS
angular.module('angularApp').filter('shipmentFilter', function() {
	return function(items, criteria){
		if (!criteria || !criteria.flags) //Initialization
			return items;
		 var filtered = [];
   		 angular.forEach(items, function(item) {
   		 	//FLAGS
   		 	if (criteria.flags.priority && item.flags.priority==0) return;
   		 	if (criteria.flags.cold && !item.flags.cold) return;
   		 	if (criteria.flags.big && !item.flags.big) return;
   		 	if (criteria.flags.dangerous && !item.flags.dangerous) return;	
   		 	if (criteria.flags.fashion && !item.flags.fashion) return;	
   		 	if (criteria.flags.live && !item.flags.live) return;
   		 	
   		 	//RANGE
   		 	if (item.weight>criteria.weight.valueMax) return;
   		 	if (item.weight<criteria.weight.valueMin) return;
   		 	if (item.vol>criteria.vol.valueMax) return;
   		 	if (item.vol<criteria.vol.valueMin) return;

   		 	filtered.push(item);
   		 });
   		 return filtered;

	}
});
angular.module('angularApp')
	.controller('flightSearchController',['$scope','$resource','FlightService', function ($scope,$resource,FlightService) {
	   //Initialization. Call FlightService with no paramenter for searching today flights
		FlightService.search(null,function(data){		    
		  		$scope.flights=data;
		  });

		$scope.searchFlights=function(){
			FlightService.search($scope.searchCriteria,function(data){		    
					  		$scope.flights=data;
					  });
		}
	}]);

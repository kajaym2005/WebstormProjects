'use strict';

angular.module('angularApp')
	.factory('FlightService', ['$resource','$exceptionHandler', function ($resource,$exceptionHandler) {
		return {
            
			/*
				OPERATION: Search 
				DESCRIPTION: Retrieves a list of flights departing today if no parameter is provided,
							If criteria are sent, the list will be filtered
			*/
            search: function(criteria, callback) {
            	var searchResource=$resource('mock/flightSearch.json',{},{'get': {method: 'GET',isArray: true }});
			    searchResource.get(callback);
            },

 
			/*
				OPERATION: Detail 
				DESCRIPTION: Retrieves the detail of a flight
			*/
			detail: function(flightName, callback) {
            	var flightService= $resource('mock/flight'+flightName+'.json',{},{ 'get': { method: 'GET', isArray: false } } );
			    flightService.get(callback);
            },
            /*
				OPERATION: getShipments 
				DESCRIPTION: Retrieves the list of shipments of a flight
			*/
			getShipments: function(flightName, callback) {
				var flightService= $resource('mock/shipments'+flightName+'.json',{},{ 'get': { method: 'GET', isArray: true } } );
			    flightService.get(callback);
            },
            addShipmentsToULD:function(flight, uld,shipments) {
            	var totalVol, totalWeight=0;
            	var err="";
            	angular.forEach(shipments, function(shipment, key){  
            		if (uld.vol.free <shipment.vol) err="Sorry, there is not enough space in container!";
          			if (uld.weight.free <shipment.weight) err="Sorry, the shipment is too heavy for the container!";
        			if (flight.spaceUtilizationSummary.free <shipment.weight) err="Sorry, the shipment is too heavy for the aircraft!";
					if (err=="") {
	            		uld.vol.used += shipment.vol;
	            		uld.vol.free -= shipment.vol;
	            		flight.spaceUtilizationSummary.used +=shipment.weight;
	            		flight.spaceUtilizationSummary.free -=shipment.weight;
	            		uld.weight.used += shipment.weight;
	            		uld.weight.free -= shipment.weight;
            		}
            	});
				if (err!="") {
					$exceptionHandler({userMsg:err});
					return false;
				}
				return true;

            	
            }
				
       }
	}]);




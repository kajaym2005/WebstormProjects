'use strict';

angular.module('angularApp', [
  'ngCookies',
  'ngResource',
  'ngSanitize',
  'ngRoute',
  'ngAnimate',
  'vr.directives.slider',
  'ngDragDrop',
])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/main.html',
        controller: 'MainCtrl'
      })
      .when('/search', {
        templateUrl: 'views/flightSearch.html',
        controller: 'flightSearchController'
      })
      .when('/buildPlan/:flightName', {
        templateUrl: 'views/buildPlan.html',
        controller: 'planeController'
      })
      .otherwise({
        templateUrl: '/',
        controller: 'MainCtrl'
      });
  });
angular.module('angularApp')
  .config(function($provide) {
    $provide.decorator("$exceptionHandler", function($delegate) {
        return function(exception, cause) {
            $delegate(exception, cause);
            if (exception.userMsg)
             {
              $("#notificationArea strong").text(exception.userMsg);
              $("#notificationArea").show("300");
               setTimeout( function(){ $("#notificationArea").hide("300")},2000);
             } 
        };
    });
}); 
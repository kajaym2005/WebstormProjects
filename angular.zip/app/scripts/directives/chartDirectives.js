'use strict';

angular.module('angularApp')
	.directive('acnPlaneChart', function () {
    return {
      restrict: 'E',
      template: '<div class="plane"><canvas class="chart"></canvas><span class="glyphicon glyphicon-plane"></span></div>',
   
      compile: function(element, attr) {
        var canvas  = element.find('canvas')[0],
            context = canvas.getContext('2d'),
            chart;
 		
        canvas.width = 120;
        canvas.height = 120;
        chart = new Chart(context);

       

        //Update when charts data changes
        //scope.$watch("value", function(newValue) {
        attr.$observe('value', function(dataAttr) {
          if(!dataAttr) return;
          var newValue=angular.fromJson(dataAttr);
          var csscolor= "#109910";
          if (newValue.free<newValue.used/2) csscolor= "#ffd400";
          if (newValue.free<newValue.used/3) csscolor= "#d9534f";
          var data = [
                  {
                  value: newValue.used,
                  color:csscolor
                },
                {
                  value : newValue.free,
                  color : "#E2EAE9"
                }
                ]
                 
          chart.Doughnut(data, {percentageInnerCutout : 80  });
        });
      }
    }
  });
	

/** BAR DIRECTIVE **/
angular.module('angularApp')
  .directive('acnbar', ['$timeout',function ($timeout) {
    return {
      restrict: 'E',
      
      scope: {
        val: '=val',
        total: '=total',
        
      },
      template: '<div class="progress progress-striped "><div class="progress-bar {{colorClass}}"  role="progressbar" aria-valuenow="{{valPct}}" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>',
      link: function(scope, element, attrs, tabsCtrl) {
        
       scope.$watch("val", function(newValue) {

          scope.valPct= newValue*100/scope.total;
          scope.colorClass='progress-bar-success';
          if (scope.valPct>50) scope.colorClass='progress-bar-warning';
          if (scope.valPct>80) scope.colorClass='progress-bar-danger';
          $timeout(function() {
            element.find(".progress-bar").css('width', scope.valPct + '%');

          })
        });

       }
    }
  }]);